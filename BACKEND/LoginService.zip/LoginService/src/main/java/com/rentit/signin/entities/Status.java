package com.rentit.signin.entities;

public enum Status {
	
	ACTIVE,
	SUSPENDED,
	BLOCKED
	
	
}
